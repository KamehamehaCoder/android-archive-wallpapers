#version 310 es

uniform mat4 u_projectionViewMatrix;
uniform mat4 u_worldMatrix;

in vec4 a_position;
in vec2 a_texCoord0;

out vec2 v_texCoord0;

void main() {
 v_texCoord0 = a_texCoord0;
 gl_Position = u_projectionViewMatrix * u_worldMatrix * a_position;
}