#version 310 es

#define PI2 3.1415926535897932384626433832795 / 2.

precision highp float;

uniform sampler2D u_texture;
uniform sampler2D u_noise;
uniform float u_time;

in vec2 v_texCoord0;

out vec4 fragColor;

float mixNoiseChannels(vec4 noiseChannels, float time) {
  float noise = 0.;
  noise += noiseChannels.r * (cos(time) * .5 + .5) * .25;
  noise += noiseChannels.g * (cos(time + PI2) * .5 + .5) * .25;
  noise += noiseChannels.b * (cos(time + 2. * PI2) * .5 + .5) * .25;
  noise += noiseChannels.a * (cos(time + 3. * PI2) * .5 + .5) * .25;
  return noise;
}

float computeNoise(vec2 uv) {
  float noise1 = mixNoiseChannels(texture(u_noise, uv * 8. + u_time * .02), u_time * 1.5);
//  float noise2 = mixNoiseChannels(texture(u_noise, (1. - uv) * 12. + u_time * .02), u_time * 2.);

  return noise1;
//  return noise1 * .6 * noise2 * .4 + noise1 * .6 + noise2 * .4;
}

vec4 bumpFromDepth(vec2 uv, vec2 resolution, float scale) {
  vec2 step = 1. / resolution;

  float height = computeNoise(uv);

  vec2 dxy = height - vec2(
      computeNoise(uv + vec2(step.x, 0.)),
      computeNoise(uv + vec2(0., step.y))
  );

  return vec4(normalize(vec3(dxy * scale / step, 1.)), height);
}

void main() {
  vec2 uv = v_texCoord0;

  float mask = smoothstep(.65, 2., 1. - distance(v_texCoord0, vec2(.65, .75)));

  vec3 normal = bumpFromDepth(uv, vec2(512.), mask).rgb;

  float lightIntensity = max(dot(normal, normalize(vec3(.2, 1., 0.))), 0.);

  fragColor = texture(u_texture, uv);
  fragColor.rgb += lightIntensity * .1 * vec3(1., 1., .7);
//  fragColor = vec4(normal * .5 + .5, 1.);
//  fragColor = vec4(vec3(computeNoise(uv)), 1.);
}