#version 310 es

precision lowp float;

uniform sampler2D u_texture;
uniform vec4 u_textureRegion;

highp in vec2 v_texCoord0;

out vec4 fragColor;

void main() {
  highp vec2 uv = vec2(u_textureRegion.x + u_textureRegion.z * v_texCoord0.x, u_textureRegion.y + u_textureRegion.w * v_texCoord0.y);
  fragColor = texture(u_texture, uv);
}