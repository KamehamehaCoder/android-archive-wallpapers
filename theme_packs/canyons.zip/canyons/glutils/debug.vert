attribute vec3 a_position;
attribute vec2 a_texCoord0;

uniform mat4 u_projTrans;
uniform float u_rotation;
varying highp vec2 v_uv;

void main()  {
    v_uv.x = cos(u_rotation) * (a_texCoord0.x -0.5) - sin(u_rotation) * (a_texCoord0.y-0.5);
    v_uv.y = sin(u_rotation) * (a_texCoord0.x -0.5) + cos(u_rotation) * (a_texCoord0.y-0.5);
    v_uv.x += 0.5;
    v_uv.y += 0.5;

  gl_Position = u_projTrans * vec4(a_position, 1.0);
}
