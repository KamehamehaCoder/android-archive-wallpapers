#version 310 es

in vec3 a_position;
in vec2 a_texCoord0;

uniform mat4 u_projTrans;
uniform vec2 u_uScale;

out vec2 v_uv;
out vec2 v_uv_init;

void main()  {
    v_uv = a_texCoord0;
    v_uv.y = 1.0 - v_uv.y;

    /* Adjustment for different Aspect Ratios */
    v_uv_init = v_uv;
    /* x */
    v_uv_init.x /= u_uScale.x;
    v_uv_init.x -= ((1. / u_uScale.x )- 1.) / 2.;
    /* y */
    v_uv_init.y /= u_uScale.y;
    v_uv_init.y -= ((1. / u_uScale.y )- 1.) / 2.;

    gl_Position = u_projTrans * vec4(a_position, 1.0);
}
