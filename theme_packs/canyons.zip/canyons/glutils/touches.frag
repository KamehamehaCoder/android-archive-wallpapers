#version 310 es
#define PI 3.14159265359
precision highp float;

uniform vec2 u_resolution;

uniform highp sampler2D u_texture;

uniform highp float u_bgd_noise;

uniform vec2 u_position;
uniform vec2 u_size;

uniform float u_blur_effect;

struct Easing {
    float heightAdj;
    float globalAdj;
    float main;
};

in float v_carving_strength;
in vec2 v_uv;
in Easing v_easing;

out vec4 fragColor;

float getValue(sampler2D image, vec2 uv) {
    return texture(image, uv).r;
}

float blur(sampler2D image, vec2 uv) {
  float imgValue = getValue(image, uv);
  float color = imgValue * 0.333;
  vec2 offset = vec2(1.0 + 3.0 * smoothstep(0.3, 0.8, imgValue)) / u_resolution;
  vec2 offXstart = vec2(offset.x, 0.0);
  vec2 offXend = -offXstart;
  vec2 offYStart = vec2(0.0, offset.y);
  vec2 offYend = -offYStart;
  color += getValue(image, uv + offXstart) * 0.1666;
  color += getValue(image, uv + offXend) * 0.1666;
  color += getValue(image, uv + offYStart) * 0.1666;
  color += getValue(image, uv + offYend) * 0.1666;
  return color;
}

void main()  {
    float textureColor = mix(getValue(u_texture, v_uv), blur(u_texture, v_uv), min(u_blur_effect + 0.1, 1.) );
    float diff = (0.0 - textureColor) * v_easing.main;
    diff *= mix(0.002, 0.0002, textureColor * v_easing.heightAdj) * v_easing.globalAdj;
    textureColor += diff;

    vec2 rad = u_position - v_uv;
    rad /= u_size;
    float distance = length(rad);
    float color = cos(min(distance, 1.0) * PI);
    color = (color + 1.) * 0.5;

    float mask = color;
    color *= v_carving_strength;
    float finalColor = min(textureColor + mix(0.0, color, mask), 1.0);
    fragColor = vec4(finalColor, 0.0, 0.0, 1.0);
}