uniform sampler2D u_texture;
uniform float u_canyons_depth;
uniform float u_height_mul;
uniform float u_plateau_thres;

vec4 getPositionIQ(vec2 uv) {
    vec4 color = texture(u_texture, uv);
    // Clamp to create plateau
    float value = min(color.r * u_height_mul, u_plateau_thres);
    return vec4(uv.x, value, uv.y, color.a);
}

/* Method recomended by Íñigo Quílez */
vec4 calculateNormalsIQ(vec2 uv, vec2 incr) {
    vec4 currentPosition = getPositionIQ(uv);

    float height = currentPosition.y;

    vec2 dxy = height - vec2(
      getPositionIQ(uv + vec2(incr.x, 0.)).y,
      getPositionIQ(uv + vec2(0., incr.y)).y);
    vec2 gradient = dxy * u_canyons_depth / incr;
    return vec4(normalize(vec3(gradient.x, 1.,gradient.y)), currentPosition.a);
}

vec4 getPosition(vec2 uv) {
    vec4 color = texture(u_texture, uv);
    // Clamp to create plateau
    float value = min(color.r * u_height_mul, u_plateau_thres);
    return vec4(uv.x, value * u_canyons_depth, uv.y, color.a);
}

vec4 calculateNormals(vec2 uv, vec2 incr) {
    vec4 currentPosition = getPosition(uv);
    vec3 tanU = getPosition(vec2(incr.x, 0.0) + uv).xyz - currentPosition.xyz;
    vec3 tanV = getPosition(vec2(0.0, incr.y) + uv).xyz - currentPosition.xyz;
    return vec4(normalize(cross(tanV, tanU)), currentPosition.a);
}