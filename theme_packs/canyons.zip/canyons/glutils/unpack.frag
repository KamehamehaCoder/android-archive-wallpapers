#version 310 es
precision highp float;

uniform highp sampler2D u_texture;
in vec2 v_uv;

out vec4 fragColor;

float unpack24 (vec4 decomp) {
   float value = dot( decomp.xyz, vec3( 255.0/256.0, 255.0/(256.0*256.0), 255.0/(256.0*256.0*256.0) ) );
   return value;
}

void main()  {
    float color = unpack24(texture(u_texture, v_uv));
    fragColor = vec4(color,color,color,1.0);
}