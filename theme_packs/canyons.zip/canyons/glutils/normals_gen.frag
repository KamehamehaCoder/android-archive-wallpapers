/* Get Normals Generated. */
uniform sampler2D u_texture;
uniform float u_canyons_depth;

vec4 calculateNormals(vec2 uv, vec2 incr) {
    vec4 color = texture(u_texture, uv);
    color.xyz = color.xyz * 2.0 - vec3(1.0);
    return color;
}

vec4 calculateNormalsIQ(vec2 uv, vec2 incr) {
    return calculateNormals(uv, incr);
}

