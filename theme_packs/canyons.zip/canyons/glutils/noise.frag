#version 310 es
precision highp float;

uniform sampler2D u_texture;
uniform vec2 u_resolution;
uniform highp float u_noise_period;
uniform float u_init_state;
uniform float u_noise_strength;
uniform float u_noise_scale;

in vec2 v_uv;
in vec2 v_uv_init;

out vec4 fragColor;

/* Other Methods */
// {=SHADER_METHODS} //

void main()  {
    vec3 st = vec3(gl_FragCoord.xy/u_resolution.xy, 1.0);
    st.x *= u_resolution.x/u_resolution.y;

    float noise = 0.0;

    // Scale the space in order to see the function
    st.xy *= u_noise_scale * 1.6;
    st.z = 1.0 + u_noise_period;

    noise = smoothstep(0.08, 0.92, (cnoise(st) + 1.0) * 0.5);
    noise *= 1.05;
//    noise += (snoise(st * 0.87534 + vec3(1.21)) + 1.0) * 0.2;
//    noise += (snoise(st * 0.9) + 1.0) * 0.240;
    noise *= u_noise_strength;

    float color = mixInitState(u_texture, noise, v_uv_init, u_init_state);
    fragColor = vec4(color, 0.0, 0.0, 1.0);
}