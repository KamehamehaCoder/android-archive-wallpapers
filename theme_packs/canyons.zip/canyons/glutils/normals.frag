in vec2 v_uv;
uniform vec2 u_resolution;
out vec4 fragColor;

void main()  {
    fragColor = calculateNormalsIQ(v_uv, u_resolution);

    /* Normalize. */
    fragColor.xyz += vec3(1.0);
    fragColor.xyz *= 0.5;
}