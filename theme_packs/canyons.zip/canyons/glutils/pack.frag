precision highp float;

uniform highp sampler2D u_texture;
varying vec2 v_uv;

vec4 pack (float depth) {
    const vec4 bitSh = vec4(256.0 * 256.0 * 256.0, 256.0 * 256.0, 256.0, 1.0);
    const vec4 bitMsk = vec4(0.0, 1.0 / 256.0, 1.0 / 256.0, 1.0 / 256.0);
    vec4 comp = fract(depth * bitSh);
    comp -= comp.xxyz * bitMsk;
    return comp;
}

vec4 pack24 (float depth) {
   float max24int = 256.0*256.0*256.0-1.0;
   vec3 decomp = floor( depth * vec3( max24int / (256.0*256.0), max24int / 256.0, max24int ) ) / 255.0;
   decomp.z -= decomp.y * 256.0;
   decomp.y -= decomp.x * 256.0;
   return vec4(decomp, 1.0);
}

void main()  {
    highp vec4 color = texture2D(u_texture, v_uv);
    gl_FragColor = pack24(color.r);
}