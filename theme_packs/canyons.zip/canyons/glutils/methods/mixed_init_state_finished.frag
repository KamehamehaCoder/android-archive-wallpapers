float mixInitState(sampler2D initState, float noise, vec2 uv, float initStep) {
    return noise;
}