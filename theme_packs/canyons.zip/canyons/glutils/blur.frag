#version 310 es
precision highp float;

uniform vec3 u_offset;
uniform highp sampler2D u_texture;

in vec2 v_uv;
out vec4 fragColor;

float getValue(sampler2D image, vec2 uv) {
    return texture(image, uv).r;
}

vec4 blur(sampler2D image, vec2 uv, vec3 offset) {
  float imgValue = getValue(image, uv);
  float color = imgValue * 0.333;
  color += getValue(image, uv + offset.xz) * 0.1666;
  color += getValue(image, uv - offset.xz) * 0.1666;
  color += getValue(image, uv + offset.zy) * 0.1666;
  color += getValue(image, uv - offset.zy) * 0.1666;
  return vec4(max(color, 0.),0.0,0.0,1.0);
}

void main()  {
    fragColor = blur(u_texture, v_uv, u_offset);
}