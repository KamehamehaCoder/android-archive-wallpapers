precision highp float;

uniform highp sampler2D u_texture;
varying vec2 v_uv;

void main()  {
    float color = texture2D(u_texture, v_uv).r;
    gl_FragColor = vec4(color, 0., 0., 1.);
    gl_FragColor.a = 0.8;
}