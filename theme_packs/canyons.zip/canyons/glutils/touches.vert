#version 310 es

#define SPEED 0.33 // Global speed at which we're adding and removing

#define HEIGHT_MIN 1.1
#define HEIGHT_MAX 0.4 // How fast we're removing highs (closer to 1 is slower)

#define GLOBAL_MIN 1.0
#define GLOBAL_MAX 50.0 // How fast we're removing everything (higher is faster)

#define Y_MIN 0.6 // Average luminosity range (min-max) when we're affecting
#define Y_MAX 0.9

in vec3 a_position;
in vec2 a_texCoord0;

uniform mat4 u_projTrans;
uniform highp sampler2D u_luminosity;
uniform highp float u_carving_strength;

struct Easing {
    float heightAdj;
    float globalAdj;
    float main;
};

uniform Easing easing;

out highp vec2 v_uv;
out Easing v_easing;
out float v_carving_strength;
out float v_luminosity;
out float v_speed;

float getLuminosity(vec2 pos) {
    return texture(u_luminosity, pos).r;
}

float getAverageLuminosity(int sx, int sy, int width, int height) {
    float colorFinal = 0.0;
    vec2 pos = vec2(0.0);
    float scale = 1.0 / 5.;
    float offset = 0.5 * scale;
    float size = float(width * height);

    for (int x = sx; x < sx + width; x++) {
        for (int y = sy; y < sy + height; y++) {
            pos.x = float(x) * scale + offset;
            pos.y = float(y) * scale + offset;
            colorFinal += getLuminosity(pos) / size;
        }
    }
    return colorFinal;
}

float getLuminosity() {
    float yCenter = getAverageLuminosity(1, 1, 3, 3);
    float yRightTop = getAverageLuminosity(2, 1, 3, 2);
    float yRightBottom = getAverageLuminosity(2, 2, 3, 2);
    float yLeftTop = getAverageLuminosity(0, 1, 3, 2);
    float yLeftBottom = getAverageLuminosity(0, 2, 3, 2);
    float maxLeft = max(yLeftTop, yLeftBottom);
    float maxRight = max(yRightTop, yRightBottom);
//    return max(yCenter, max(maxLeft, maxRight));
    return yCenter;
}




void main()  {
    v_uv = a_texCoord0;
    v_uv.y = 1.0 - v_uv.y;

    float luminosity = getLuminosity();
    v_easing = easing;
    v_luminosity = smoothstep(Y_MIN, Y_MAX, luminosity);
    v_luminosity *= v_luminosity;
    v_easing.heightAdj = mix(HEIGHT_MIN, HEIGHT_MAX, v_luminosity) * SPEED;
    v_easing.globalAdj = mix(GLOBAL_MIN, GLOBAL_MAX, v_luminosity) * SPEED;
    v_carving_strength = u_carving_strength * mix(1.0, 0.1, v_luminosity) * SPEED;
    v_speed = SPEED;
    gl_Position = u_projTrans * vec4(a_position, 1.0);
}
