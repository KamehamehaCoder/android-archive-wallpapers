#version 310 es
precision highp float;

in vec2 v_uv;

uniform highp sampler2D u_texture;
uniform highp sampler2D u_noise;
uniform float u_canyons_depth;
uniform float u_height_mul;
uniform float u_plateau_thres;

out vec4 fragColor;

float getValue (vec2 pos) {
    return texture(u_texture, pos).r;
}

float getNoise (vec2 pos) {
    return texture(u_noise, pos).r;
}

float getPosition(vec2 uv) {
    float color = getValue(uv);
    float noise = getNoise(uv);

    // Mix noise and texture
    float value = noise + color;

    // Generate a position map
    return min(value, 1.0);
}

void main()  {
    u_height_mul;
    u_plateau_thres;
    u_canyons_depth;
    fragColor = vec4(getPosition(v_uv), 0., 0., 1.);
}