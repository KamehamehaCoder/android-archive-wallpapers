#version 310 es

in vec3 a_position;
in vec2 a_texCoord0;

uniform mat4 u_projTrans;
uniform float u_rotation;
uniform float u_aspect_ratio;

out highp vec2 v_uv;
out vec2 v_position;

void main()  {
    float invY = 1. - a_texCoord0.y;
    v_uv.x = cos(u_rotation) * (a_texCoord0.x -0.5) - sin(u_rotation) * (invY-0.5);
    v_uv.y = sin(u_rotation) * (a_texCoord0.x -0.5) + cos(u_rotation) * (invY-0.5);
    v_uv.x += 0.5;
    v_uv.y += 0.5;


    v_position = vec2(a_texCoord0.x, invY);
    v_position.x *= abs(cos(u_rotation) - sin(u_rotation) * u_aspect_ratio);
    v_position.y *= abs(sin(u_rotation) + cos(u_rotation) * u_aspect_ratio);

  gl_Position = u_projTrans * vec4(a_position, 1.0);
}
