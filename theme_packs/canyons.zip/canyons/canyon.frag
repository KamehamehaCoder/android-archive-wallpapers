
uniform mat4 u_modelViewTrans;
uniform mat4 u_normTrans;
uniform vec2 u_incr;

struct Material {
    vec4 ambient;
    vec4 diffuse;
    float specularShininess;
    float specularStrength;
};

uniform Material u_material;

struct Light {
    vec3 position;
    float intensity;
};

uniform Light u_light;

in highp vec2 v_uv;
in vec2 v_position;

out vec4 fragColor;

void main()  {
    vec4 normals = calculateNormalsIQ(v_uv, u_incr); // Alpha channel contains depth.
    float depth = (normals.a - 1.0) * u_canyons_depth;
    vec3 position = vec3(v_position.x, depth, v_position.y);
    vec3 N = normals.xyz;
    vec3 L = u_light.position - position;

    /* Calculate light effect */
    float lightDirection = dot(N, L); // Light direction
    float lightIntensity = u_light.intensity / (length(L) * length(L)); // Light Intensity.
    float brightness = lightDirection * lightIntensity;
    brightness = smoothstep(0.0, 1.0, brightness);

    /*  Calculate Diffuse + Ambient. */
    fragColor = vec4(mix(u_material.ambient.rgb, u_material.diffuse.rgb, brightness), 1.0); // add here light color

    /*  Calculate specular. */
    vec3 eyeNormal = (u_normTrans * vec4(N, 1.0)).xyz;
    vec3 eye = (u_modelViewTrans * vec4(position, 1.0)).xyz;
    vec3 E = normalize( -eye );
    vec3 EN = normalize( eyeNormal );
    vec3 L2 = normalize( u_light.position - eye );

    float specular = max(0.0, dot(reflect(-L2, EN), E));
    specular = pow(specular, u_material.specularShininess) * u_material.specularStrength;

    fragColor += vec4(vec3(mix(0.0, specular, brightness)), 1.0);

    /* Dithering. */
    fragColor = Dither_InterleavedGradientNoise(fragColor);

    /*  Debug light Position. */
//    float rad = 1.0 - min(length((u_light.position.xz - position.xz)) * 10.0, 1.0);
//    fragColor.r += rad;

    /*  Debug Utils. */
//    fragColor = vec4(1. / length(L), 0., 0., 1.0);
//    fragColor = vec4(getNormalsValue(), 1.0);
//    fragColor = vec4(N, 1.0);
//    fragColor = vec4(brightness, 0.0, 0.0, 1.0);
//    fragColor = vec4(step(1.4, position.z), 0.0, 0.0, 1.0);
}